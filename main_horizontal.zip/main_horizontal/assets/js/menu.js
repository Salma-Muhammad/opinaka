/*function openLink() {
    window.open(this.href);
    return false
} 
var link = '';

function openLink(url) {
    if (link != url) {
        window.location = "url";
    } else {
        link = url;
        window.open(url, '_blank');
        return false;
    }
}*/

/*$(document).ready(function() {
    var newWin; // declare variable global
    $("#link_logo").click(function() {
        newWin = window.open(this.href);
    })
})

$(document).ready(function() {
    var newWin; // declare variable global
    $("#link_open").click(function() {
        newWin = window.open(this.href);
        return false;
    })
})*/
$(document).ready(function() {
    $('a#link_open').click(function() {
        window.open(this.href);
        return false;
    });
});