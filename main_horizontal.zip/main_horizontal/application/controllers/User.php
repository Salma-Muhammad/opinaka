<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller 
{
    public function index(){
        $this->load->view('user');
    }
    public function login(){
        if ($this->input->post()) { 
        $data = $this->input->post(); //permet de récupérer en une seule fois toutes les données envoyées par le formulaire. Equivaut au tableau $_POST en PHP natif.
        // personnalise le style des messages d'erreurs
        $this->form_validation->set_error_delimiters('<div class="alert alert-danger mt-1" style="font-size: 14px;">', '</div>');  
        // Traitement des données rentrées dans le formulaire.
        $this->form_validation->set_rules("email", "E-mail", "required", array("required" => "Veuillez renseigner votre %s."));                  
        $this->form_validation->set_rules("pass", "Mot de passe", "required", array("required" => "Veuillez renseigner votre %s."));                
        }
        //run() permet d'exécuter la vérification des filtres
        if ($this->form_validation->run() == FALSE) { 
                    $this->load->view('user');
        }else{ 
        // La validation a réussi, nos valeurs sont bonnes, on peut insérer en base
        $email = $data['email'];
        $password = $data['pass'];
        $user="dany@opinaka.online";
        $pass="$(-rSTU36kd7)-$";
        if($email == $user && $password == $pass){
            echo"ok";
        }else{
            echo "mot de passe incorrect";
        }

        }
        
        /*$authhost="{imap.ionos.fr:143}";
        $user="dany@opinaka.online";
        $pass="$(-rSTU36kd7)-$";

        $mbox=@imap_open( $authhost, $user, $pass, OP_HALFOPEN,1);
        imap_errors();
        imap_alerts();
        if ($mbox){
            echo "<h1>Connected</h1>\n";
            imap_close($mbox);
        } else{       
            echo "<h1>FAIL!</h1>\n";
        }*/
    }
}
    