<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Menu extends CI_Controller 
{
    public function index(){
        $this->load->model('Menu_model');
        //appel de la methode et organise un tableau 
        $data['liste_app']= $this->Menu_model->liste_app();
        $Menu ["menu_header"]= $this->Menu_model->affiche1();
        $ajson["liste_menu"] = $this->Menu_model->liste_menu1(); 
        $bjson["logo_header"] = $this->Menu_model->plateform();
        //$bjson["logo_header"]+= ["id_page" => "0"];
        array_push($bjson,"id_page");
        // echo "<pre>";
        // var_dump($bjson);
        // echo "</pre>";
        $this->load->view('template', $data + $ajson + $bjson + $Menu);
    }
    public function menu1($id){
        $this->load->model('Menu_model');
        $data['liste_app']= $this->Menu_model->liste_app();
        //appel de la methode et organise un tableau 
        $Menu["menu_header"]= $this->Menu_model->affiche($id);
        $ajson["liste_menu"] = $this->Menu_model->liste_menu($id); 
        $bjson["logo_header"]= $this->Menu_model->plateform();
        //$bjson["logo_header"]+= ["id_page" =>$id];
        array_push($bjson,$id);
        // echo "<pre>";
        // var_dump($bjson);
        // echo "</pre>";
        $this->load->view('template', $data + $ajson + $bjson + $Menu);
    }
    public function page_lien($id){
        $this->load->model('Menu_model');
        $data['liste_app']= $this->Menu_model->liste_app();
        //appel de la methode et organise un tableau 
        $Menu["menu_header"]= $this->Menu_model->affiche($id);
        $ajson["liste_menu"] = $this->Menu_model->liste_menu($id); 
        // $bjson["sous_menu"] = $this->Menu_model->sous_menu();
        // $this->load->view('lien', $data + $ajson + $bjson + $Menu);
        $this->load->view('home', $Menu + $data + $ajson);
    }
    //function test
    public function test()
    {
        $this->load->model('Menu_model');
        $salut["menu_header"]= $this->Menu_model->plateform();
        echo "<pre>";
        var_dump($salut);
        echo "</pre>";
    }
}