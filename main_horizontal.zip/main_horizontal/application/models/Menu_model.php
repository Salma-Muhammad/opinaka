<?php 
	
if (!defined('BASEPATH')) exit('No direct script access allowed');
    
class Menu_model extends CI_Model
{
    public function affiche($id )
    {
        $query = $this->db->query("SELECT id_app, nom_app, description_app, logo_app FROM public.opi_app WHERE id_app= ?", $id);
        $result = $query->result();
        return $result;
    }
    public function liste_menu($id)
    {
        $json_data = $this->db->query("SELECT value ->>'link_name' as nav_items,
        value ->>'href' as link, value->>'icon' as icon,
		value->'submenu' as test_sousmenu
        FROM public.opi_app, json_array_elements(opi_app.menu_app->'items') WHERE id_app= ?", $id);
        $json = $json_data->result();
        return $json;
    }
    public function sous_menu()
    {
        $json_data = $this->db->query("SELECT submenu ->> 'text' as sous_menu
        from ( select json_array_elements(json_array_elements(opi_app.menu_app->'items')->'submenu') AS submenu
        FROM  opi_app where id_app= 1) as derivable;");
        $json = $json_data->result();
        return $json;
    }
    //affiche toute les app
    public function liste_app()
    {
        $query = $this->db->query("SELECT id_app, nom_app, description_app FROM public.opi_app order by nom_app asc");
        $result = $query->result();
        return $result;
    }
    //affichage test de la 1ere app
    public function affiche1()
    {
        $query = $this->db->query("SELECT id_app, nom_app, description_app, logo_app FROM public.opi_app WHERE id_app= 1");
        $result = $query->result();
        return $result;
    }
    public function liste_menu1()
    {
        $json_data = $this->db->query("SELECT value ->>'link_name' as nav_items,
        value ->>'href' as link, value->>'icon' as icon,
		value->'submenu' as test_sousmenu
        FROM public.opi_app, json_array_elements(opi_app.menu_app->'items') WHERE id_app= 1");
        $json = $json_data->result();
        return $json;
    }
    //affichage de la table opi_plateform
    public function plateform(){
    $json_data = $this->db->query("SELECT id, name, logo, description, url FROM public.opi_plateform ORDER BY id ASC ");
    $json = $json_data->result();
    return $json;
    }


}/*SELECT value ->>'link_name' as nav_items,
        value ->>'href' as link, 
		value->>'icon' as icon,
		json_array_elements(value->'submenu') as salut
        FROM public.opi_app, json_array_elements(opi_app.menu_app->'items') where id_app = 1 ;*/