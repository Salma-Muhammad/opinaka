<?php
$html_title ='Bienvenue';
?>


<?php ob_start(); ?>

<h2>Bienvenue sur ce site générique!</h2>


<?php $content = ob_get_clean(); ?>

<?php require('template.php'); ?>