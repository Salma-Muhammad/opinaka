<?php $html_title ='Menu horizontal';
require('header.php');
?>

<body class="container-fluid px-0">

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark ">
    <!--logo -->
    <?php /* code qui fonctionne
    foreach ($menu_header as $row ){?>
            <a class="pr-3 font-weight-bold navbar-brand " id='header' href="<?= site_url('menu/page_lien/'.$row->id_app); ?>" >
            <img src="<?= base_url("assets/img/".$row->logo_app);?>" width="40px" height="40px" alt="Logo_app">
            <?= $row->nom_app ;?></a>
        <?php }*/ ?>
    <?php
    foreach ($logo_header as $row ){ ?>
        <a class='pr-3 navbar-brand' href="">
        <?= $row->logo; ?>
        </a>
    <?php } ?>

<?php /* if([0] != "0"){
    
        foreach ($logo_header as $row ){
        echo "<a class='pr-3 navbar-brand' href=".$row->url.'index.php/menu/menu1/'.[0]." target='_blank'>";
        echo $row->logo; 
        echo "</a>";
        }
    }else{ 
        foreach ($logo_header as $row ){
        echo "<a class='pr-3 navbar-brand' href=".$row->url." target='_blank'>";
        echo $row->logo;
        echo "</a>"; 
        }
    } */?>


<!-- button burger -->
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#menu_principal" aria-controls="menu_principal" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
</button>

<!-- affichage menu -->
    <div class="collapse navbar-collapse" id="menu_principal">
        <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
        <?php foreach ($liste_menu as $row ){ 
            $json = json_decode($row->test_sousmenu,true); ?>
            <li class="nav-item active">
            <?php  if ($json != null){  ?> 
            <div class='dropdown'>
                <a class='btn nav-link active dropdown-toggle' href='<?= $row->link; ?>' role='button' id='dropdownMenu'  data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
                    <i class='<?= $row->icon; ?>'></i>
                    <?= $row->nav_items; ?></a>
                <div class='dropdown-menu' aria-labelledby='dropdownMenu'>
                    <?php foreach($json as $row){ ?>
                    <a class='dropdown-item' id='link_open' role='button' href='<?= $row['href']; ?>'><?= $row['text'] ?></a>
                    <?php } //end foreach ?>
                </div>
            </div> 
                <?php }else { ?>
                    <a class='btn nav-link active' id='link_open' href="<?= $row->link;?>"  role='button'>
                    <i class='<?= $row->icon; ?>'></i>
                    <?= $row->nav_items; ?></a>
                <?php } //end if?>
            </li>
            <?php } // end foreach ?>
        </ul>
        <!-- bouton choix applications -->
        <div class="dropdown">
        <button class="btn btn-info dropdown-toggle mx-5" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        Apps
        </button>
            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <?php foreach($liste_app as $row){ ?>
                <a class="dropdown-item" href="<?= site_url('menu/menu1/'.$row->id_app); ?>" ><?= $row->nom_app; ?></a><?php } ?> 
            </div>
        </div>
    </div><!-- End Collapse -->
</nav> 

<!-- Contenu description -->
<div class="col-8 offset-2">
<?php foreach ($menu_header as $row ){ 
    if ($row->logo_app != null || $row->logo_app != ""){ ?>
    <h1 class="text-center my-5">
    <img src="<?= base_url('assets/img/'.$row->logo_app); ?>" alt="Logo menu" width="40px" height="40px"> 
    <?= $row->nom_app; ?></h1>
    <?php }else{ ?>
    <h1 class="text-center my-5"><?= $row->nom_app; ?></h1>
    <?php } ?>
    <hr class="text-center" height='30px' style="border-radius: 20px">
        <?= $row->description_app;?>
    <?php }?>
</div>


<?php require('footer.php');
?>