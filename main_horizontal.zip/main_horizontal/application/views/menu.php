<?php
$html_title ='Menu horizontal';
require('header.php'); ?>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
<!--logo -->
<a class="pr-3 font-weight-bold navbar-brand">
<?php foreach ($menu_header as $row ){ ?>
    <img src="<?= base_url("assets/img/".$row->logo_app);?>" width="40px" height="40px" alt="Logo_app"> <?=$row->nom_app; }?>
</a> 

<!-- button burger -->
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#menu_principal" aria-controls="menu_principal" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
</button>

<div class="collapse navbar-collapse" id="menu_principal">
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
    <?php foreach ($liste_menu as $row){ 
        $json = json_decode($row->test_sousmenu,true); ?>
        <li class="nav-item active">
        <?php  if ($json != null){  ?> 
        <div class='dropdown'>
            <a class='btn nav-link active' href='<?= $row->link; ?>' target="_blank" role='button' id='dropdownMenu' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
                <i class='<?= $row->icon; ?>'></i>
                <?= $row->nav_items; ?></a>
            <div class='dropdown-menu' aria-labelledby='dropdownMenu'>
                <?php foreach($json as $row){ ?>
                <a class='dropdown-item' role='button' href='<?= $row['href']; ?>' target="_blank"><?= $row['text'] ?></a>
                <?php } //end foreach ?>
            </div>
        </div> 
            <?php }else { ?>
                <a class='btn nav-link active' href='<?= $row->link; ?>' target="_blank" role='button'>
                <i class='<?= $row->icon; ?>'></i>
                <?= $row->nav_items; ?></a>
            <?php } //end if?>
        </li>
        <?php } // end foreach ?>
    </ul>
    <?php /*<a class="btn btn-info" href="<?= site_url("menu/config"); ?>" role="button" target='iframe_a' >  Configuration</a>*/?>
</div><!-- End Collapse -->
</nav> 

<!-- <iframe style="width: 100%; height: 700px; overflow: show; border:1px solid #000;" name="iframe_a" src="<?= base_url("application/views/demo.html"); ?>" scrolling="yes"></iframe> -->
<?php require('footer.php'); ?>
