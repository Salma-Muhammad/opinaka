<?php
$html_title ='Configuration';
require("header.php");
?>
<body class="container">
<div class="row mt-5 pt-5">
    <div class="col-md-4 offset-4">
        <fieldset>
            <?= form_open();  ?>  
            <h1 class="h3 mb-3 font-weight-normal my-3 ml-2">Sign in</h1>
            <div class="form-group mx-2">
                <input type="email" name="email" id="inputEmail" class="form-control" placeholder="Email address" >
                <?= form_error('email'); ?>
            </div>
            <div class="form-group mx-2">
                <input type="password" name="pass" id="inputPassword" class="form-control" placeholder="Password" >
                <?= form_error('pass'); ?>
            </div>
            <div class="d-flex justify-content-center">
                <input type="submit" class="btn btn-outline-success my-2 text-center" formaction="<?= site_url('User/login'); ?>"value="Sign in">
            </div>
            </form>
        </fieldset>
    </div>
</div>
<?php
require("footer.php");
?>