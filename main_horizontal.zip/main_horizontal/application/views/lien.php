<?php
$html_title ='lien';

?><?php ob_start(); ?>
<?php echo $data; ?>
<?php $content = ob_get_clean(); ?>

<?php require('template.php'); ?>

