<?php 
	
if (!defined('BASEPATH')) exit('No direct script access allowed');
    
class Menu_model extends CI_Model
{
    //application choix
    public function affiche($id )
    {
        $query = $this->db->query("SELECT id_app, nom_app, description_app, logo_app FROM public.opi_app WHERE id_app= ?", $id);
        $result = $query->result();
        return $result;
    }
    //menu choix
    public function liste_menu($id)
    {
        $json_data = $this->db->query("SELECT value ->>'link_name' as nav_items,
        value ->>'href' as link, value->>'icon' as icon,
		value->'submenu' as test_sousmenu
        FROM public.opi_app, json_array_elements(opi_app.menu_app->'items') WHERE id_app= ?", $id);
        $json = $json_data->result();
        return $json;
    }
    //liste de toute les applications controllers/index
    public function liste_app()
    {
        $query = $this->db->query("SELECT id_app, nom_app, description_app FROM public.opi_app order by id_app asc");
        $result = $query->result();
        return $result;
    }
    //application definie par defaut
    public function affiche1()
    {
        $query = $this->db->query("SELECT id_app, nom_app, description_app, logo_app FROM public.opi_app WHERE id_app= 1");
        $result = $query->result();
        return $result;
    }
    //menu definit par defaut
    public function liste_menu1()
    {
        $json_data = $this->db->query("SELECT value ->>'link_name' as nav_items,
        value ->>'href' as link, value->>'icon' as icon,
		value->'submenu' as test_sousmenu
        FROM public.opi_app, json_array_elements(opi_app.menu_app->'items') WHERE id_app= 1");
        $json = $json_data->result();
        return $json;
    }
}