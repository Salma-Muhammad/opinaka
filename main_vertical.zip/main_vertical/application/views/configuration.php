<?php
$html_title ='Configuration';
?>

<?php ob_start(); ?>
<div class=" mt-5 pt-5">
    <div class="card mx-auto" style="width: 20rem;">
        <div class="card-body">
        <h5 class="card-title text-center">Configuration</h5>
        
        <?php echo form_open_multipart(); ?> 
        <select class="browser-default custom-select mt-3"name="id_app" id="id_app" value="<?= set_value('id_app'); ?>">
            <option selected disabled>Choix application</option>
            <?php foreach($liste_app as $row){ ?>
            <option value="<?= $row->id_app;?>"<?= set_select('id_app', $row->id_app);?>><?= $row->nom_app; ?></option>
            <?php } ?>
        </select>
        <button type="submit" class="btn btn-outline-success mt-3">Submit</button>
        </form>
        </div>
    </div>
</div>

<?php $content = ob_get_clean(); ?>

<?php require('template.php'); ?>
