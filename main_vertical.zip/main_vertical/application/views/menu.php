<?php
$html_title ='Menu Vertical';
require("header.php");
?>

<!-- navbar top-->
<nav id="navbar-top" role="navigation" class="header-navbar navbar-expand-sm navbar navbar-with-menu navbar-shadow navbar-border">
    <div class="justify-content-between">
        <a href="https://www.facebook.com/" class="nav-brand">
            <i class="fab fa-facebook-f"></i> 
        </a>
        <a href="https://www.instagram.com/?hl=fr" class="nav-brand">
            <i class="fab fa-instagram"></i>
        </a>
        <a href="https://twitter.com/login?lang=fr" class="nav-brand">
            <i class="fab fa-twitter"></i>
        </a>
    </div>
    <div class="ml-auto"> 
        <form class="form-inline mt-2 mt-md-0 ">
            <input class="form-control form-control-sm mr-sm-2" type="text" placeholder="Search" aria-label="Search">
            <button class="btn btn-sm btn-outline-success my-2 my-sm-0 justify-content-center" type="submit">Search</button>
        </form>
    </div>
</nav>

<div class="row">
    <!-- BEGIN Navigation-->
    <nav id="sidebar" class="col-2 navbar navbar-expand-md fixed-left">
        <div class="col-12">
            <div class="navbar-brand" style="color: azure;">
            <?php foreach ($menu_header as $row ){ ?>
                <?= $row->nom_app ;?>
            <?php } ?>
            </div>
            <hr>
            <!-- button burger -->
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#menu_principal" aria-controls="menu_principal" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="menu menu-dark menu-native-scroll menu-shadow">
                <nav class="nav flex-column">
                <!-- menu dynamic -->
                <div id="menu_principal">
                    <ul class="nav flex-column">
                    <?php
                    foreach ($liste_menu as $row ){ 
                        $json = json_decode($row->test_sousmenu,true); ?>
                        <li class="nav-item">
                        <?php  if ($json != null){  ?> 
                            <?= "sefhvhb";?>
                        <div class='dropdown'>
                            <a class='btn nav-link active' href='<?= $row->link; ?>' target='_self' role='button' id='dropdownMenu' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
                                <i class='<?= $row->icon; ?>'></i>
                                <?= $row->nav_items; ?></a>
                            <div class='dropdown-menu' aria-labelledby='dropdownMenu'>
                                <?php foreach($json as $row){ ?>
                                <a class='dropdown-item' role='button' href='<?= $row['href']; ?>' target='_blank'><?= $row['text'] ?></a>
                                <?php } //end foreach ?>
                            </div>
                        </div> 
                            <?php }else { ?>
                                <a class='btn nav-link active' href='<?= $row->link; ?>' target='_blank' role='button'>
                                <i class='<?= $row->icon; ?>'></i>
                                <?= $row->nav_items; ?></a>
                            <?php } //end if?>
                        </li>
                        <?php } // end foreach ?> 
                    </ul>
                </div>
                </nav>
            </div>
        </div>
    </nav>
    <!-- END Navigation-->
    <!-- BEGIN Content-->
    <div class="col-9 content app-content">
        <div class="content-wrapper">
            <!-- content header-->
            <div class="content-heade row  bg-secondary">
                <h1>contenu du header</h1>
            </div>
            <!-- content header-->
            <div>
            <iframe style="width: 100%; height: 400px; overflow: show; border:1px solid #000;" name="iframe_a" src="" scrolling="yes"></iframe>
            </div>
            <!-- content body-->
            <div class="content-body bg-warning ">
                contenu message
            </div>
            <div class="form-group content-bottom shadow-textarea ">
                <textarea class="form-control z-depth-1" id="exampleFormControlTextarea6" rows="3" placeholder="Envoyer un message..."></textarea>
            </div>
            <!-- content body-->
        </div>
    </div>
    <!-- END Content-->
</div>

</body>

<?php require("footer.php"); ?>