<?php $html_title ='Menu Vertical';
require('header.php');
?>

<body class="container-fluid">
<!-- navbar top-->
<div class="row">
    <nav class="navbar navbar-dark bg-dark col-md-12" >
    <div class="justify-content-between">
        <a href="https://www.facebook.com/" class="nav-brand" >
            <i class="fab fa-facebook-f"></i> 
        </a>
        <a href="https://www.instagram.com/?hl=fr" class="nav-brand">
            <i class="fab fa-instagram"></i>
        </a>
        <a href="https://twitter.com/login?lang=fr" class="nav-brand">
            <i class="fab fa-twitter"></i>
        </a>
    </div>
    <div class="dropdown">
        <button class="btn btn-info dropdown-toggle mx-5" type="button" id="buttonApps" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        Apps
        </button>
        <div class="dropdown-menu" aria-labelledby="buttonApps">
        <?php foreach($liste_app as $row){ ?>
            <a class="dropdown-item" href="<?= site_url('menu/menu1/'.$row->id_app); ?>" ><?= $row->nom_app; ?></a><?php } ?> 
        </div>
    </div>
    </nav>
</div>
<!-- End navbar top -->

<!-- Begin sidebar-->
<div class="row">
    <div id="sidebar" class="navbar fixed-left ">
        <nav>
        <?php foreach ($menu_header as $row){?>
            <a class="pr-3 font-weight-bold navbar-brand " id='header' href="<?= site_url('menu/page_lien/'.$row->id_app); ?>" >
            <img src="<?= base_url("assets/img/".$row->logo_app);?>" width="40px" height="40px" alt="Logo_app">
            <?= $row->nom_app ;?></a>
        <?php } ?>
        <!-- </div> -->
        <hr>
        <!-- menu dynamic -->
        <!-- <div id="menu_principal"> -->
        <ul class="list-unstyled">
        <?php
        $i=0;
        foreach ($liste_menu as $row ){ 
        $json = json_decode($row->test_sousmenu,true); ?>
            <li>
            <?php  if ($json != null){  ?> 
                <a class='btn nav-link dropdown-toggle' href="<?='#homeSubmenu'.$i ;?>" role='button' data-toggle='collapse' aria-expanded='false' aria-controls="<?='homeSubmenu'.$i ;?>">
                <i class='<?= $row->icon; ?>'></i>
                <?= $row->nav_items; ?></a>
                <div class="collapse" id="<?='homeSubmenu'.$i ;?>">
                    <div class="card card-body py-0" id="cardSidebar">
                        <ul class="list-unstyled">
                            <?php foreach($json as $row){ ?>
                            <li>
                            <a class='btn nav-link'role='button' href='<?= $row['href']; ?>' target="_blank"><?= $row['text'] ?></a>
                            </li>
                        <?php } //end foreach json ?>
                        </ul>
                    </div>  
                </div>
            <?php }else { ?>
                <a class='btn nav-link' href='<?= $row->link; ?>' role='button' target="_blank">
                    <i class='<?= $row->icon; ?>'></i>
                    <?= $row->nav_items; ?>
                </a>
            <?php } //end if?>
            </li>
        <?php $i++; } // end foreach liste_menu ?>
        </ul>
        </nav>
    </div>
    <!-- END Navigation-->

    <!-- Contenu description -->
    <div class="col-lg-6 offset-2">
        <?php foreach ($menu_header as $row ){ ?>
        <h1 class="text-center my-5"><?= $row->nom_app; ?></h1><?php } ?>
        <hr class="text-center" height='30px' style="border-radius: 20px">

        <?php foreach ($menu_header as $row ){ 
            echo $row->description_app;
        }?>
    </div>
    <!--END contenu description-->
</div>
<!-- End row -->
<?php require("footer.php"); ?>