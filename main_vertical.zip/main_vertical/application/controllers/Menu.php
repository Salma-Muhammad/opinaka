<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Menu extends CI_Controller 
{
    /**
     * fonction qui récupere les données du menu et sous menu 
     * venant du model et afficher le menu 1
     *
     * @return un tableau de données
     */
    public function index(){
        $this->load->model('Menu_model');
        $data['liste_app']= $this->Menu_model->liste_app();
        //appel de la methode et organise un tableau 
        $Menu ["menu_header"]= $this->Menu_model->affiche1();
        $ajson["liste_menu"] = $this->Menu_model->liste_menu1(); 
        $this->load->view('template', $data + $ajson + $Menu);  
    }
    /**
     * fonction qui va permettre de choisir le menu 
     *
     * @return l'id du menu choisi
     */
    public function config(){
        $this->load->model('Menu_model');
        $data['liste_app']= $this->Menu_model->liste_app();
        $this->load->view('configuration', $data);
        if ($this->input->post()) 
        {
        $data1 = $this->input->post();
        $id = $data1['id_app'];
        //echo "<pre>";
        // var_dump($ajson);
        // echo "</pre>";
        }
    }
    /**
     * fonction qui va permettre d'afficher le menu choisi
     *
     * @param [string] $id
     * @return un tableau de données contenant le menu
     */
    public function menu1($id){
        $this->load->model('Menu_model');
        $data['liste_app']= $this->Menu_model->liste_app();
        //appel de la methode et organise un tableau 
        $Menu["menu_header"]= $this->Menu_model->affiche($id);
        $ajson["liste_menu"] = $this->Menu_model->liste_menu($id); 
        //$bjson["sous_menu"] = $this->Menu_model->sous_menu();
        $this->load->view('template', $data + $ajson + $Menu);
    }
    /**
     * fonction permettant la redirection du menu choisi vers le meme menu
     *
     * @param [string] $id
     * @return un tableau de données contenant le menu
     */
    public function page_lien($id){
        $this->load->model('Menu_model');
        $data['liste_app']= $this->Menu_model->liste_app();
        //appel de la methode et organise un tableau 
        $Menu["menu_header"]= $this->Menu_model->affiche($id);
        $ajson["liste_menu"] = $this->Menu_model->liste_menu($id); 
        // $bjson["sous_menu"] = $this->Menu_model->sous_menu();
        // $this->load->view('lien', $data + $ajson + $bjson + $Menu);
        $this->load->view('template', $Menu + $data + $ajson);
    }
}